package com.example.compalintapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class developer extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_developer);
    }
}
